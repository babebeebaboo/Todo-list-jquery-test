$(document).ready(function() {

    $('#btn1').click(function() {

        var toAdd = $('input[name=checkListItem]').val();

        $('.list').append('<div class="item">' + toAdd + '</div>'+'<button class="itembtn">' + "Complete" + '</button>');

        $(document).on('click', '.itembtn', function() {
            $(this).remove();
            $('.item').remove();
        });

    });

});